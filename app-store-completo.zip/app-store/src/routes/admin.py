from flask import Blueprint, request, jsonify, session
from src.models.admin import Admin, db
from src.models.app import App
from src.models.comment import Comment
from werkzeug.utils import secure_filename
import os
import json
from datetime import datetime

admin_bp = Blueprint('admin', __name__)

def admin_required(f):
    """Decorator para verificar se o usuário está logado como admin"""
    def decorated_function(*args, **kwargs):
        if 'admin_id' not in session:
            return jsonify({
                'success': False,
                'error': 'Acesso negado. Login necessário.'
            }), 401
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@admin_bp.route('/login', methods=['POST'])
def admin_login():
    """Login do administrador"""
    try:
        data = request.get_json()
        
        if not data or not data.get('username') or not data.get('password'):
            return jsonify({
                'success': False,
                'error': 'Username e password são obrigatórios'
            }), 400
        
        admin = Admin.query.filter_by(username=data['username']).first()
        
        if admin and admin.check_password(data['password']) and admin.active:
            session['admin_id'] = admin.id
            admin.last_login = datetime.utcnow()
            db.session.commit()
            
            return jsonify({
                'success': True,
                'admin': admin.to_dict()
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Credenciais inválidas'
            }), 401
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@admin_bp.route('/logout', methods=['POST'])
@admin_required
def admin_logout():
    """Logout do administrador"""
    session.pop('admin_id', None)
    return jsonify({
        'success': True,
        'message': 'Logout realizado com sucesso'
    })

@admin_bp.route('/apps', methods=['POST'])
@admin_required
def create_app():
    """Criar um novo aplicativo"""
    try:
        data = request.get_json()
        
        required_fields = ['name', 'description', 'version', 'category', 'download_url']
        for field in required_fields:
            if not data or not data.get(field):
                return jsonify({
                    'success': False,
                    'error': f'Campo {field} é obrigatório'
                }), 400
        
        app = App(
            name=data['name'],
            description=data['description'],
            version=data['version'],
            category=data['category'],
            download_url=data['download_url'],
            icon_url=data.get('icon_url'),
            screenshots=json.dumps(data.get('screenshots', [])) if data.get('screenshots') else None,
            featured=data.get('featured', False)
        )
        
        db.session.add(app)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'app': app.to_dict()
        }), 201
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@admin_bp.route('/apps/<int:app_id>', methods=['PUT'])
@admin_required
def update_app(app_id):
    """Atualizar um aplicativo existente"""
    try:
        app = App.query.get_or_404(app_id)
        data = request.get_json()
        
        if data.get('name'):
            app.name = data['name']
        if data.get('description'):
            app.description = data['description']
        if data.get('version'):
            app.version = data['version']
        if data.get('category'):
            app.category = data['category']
        if data.get('download_url'):
            app.download_url = data['download_url']
        if data.get('icon_url'):
            app.icon_url = data['icon_url']
        if data.get('screenshots'):
            app.screenshots = json.dumps(data['screenshots'])
        if 'featured' in data:
            app.featured = data['featured']
        
        app.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'success': True,
            'app': app.to_dict()
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@admin_bp.route('/apps/<int:app_id>', methods=['DELETE'])
@admin_required
def delete_app(app_id):
    """Deletar um aplicativo"""
    try:
        app = App.query.get_or_404(app_id)
        db.session.delete(app)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Aplicativo deletado com sucesso'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@admin_bp.route('/comments', methods=['GET'])
@admin_required
def get_comments():
    """Listar todos os comentários para moderação"""
    try:
        comments = Comment.query.order_by(Comment.created_at.desc()).all()
        
        return jsonify({
            'success': True,
            'comments': [comment.to_dict() for comment in comments]
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@admin_bp.route('/comments/<int:comment_id>/approve', methods=['PUT'])
@admin_required
def approve_comment(comment_id):
    """Aprovar ou desaprovar um comentário"""
    try:
        comment = Comment.query.get_or_404(comment_id)
        data = request.get_json()
        
        comment.approved = data.get('approved', True)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'comment': comment.to_dict()
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@admin_bp.route('/stats', methods=['GET'])
@admin_required
def get_stats():
    """Obter estatísticas do sistema"""
    try:
        total_apps = App.query.count()
        total_downloads = db.session.query(db.func.sum(App.downloads_count)).scalar() or 0
        total_comments = Comment.query.count()
        pending_comments = Comment.query.filter_by(approved=False).count()
        
        return jsonify({
            'success': True,
            'stats': {
                'total_apps': total_apps,
                'total_downloads': total_downloads,
                'total_comments': total_comments,
                'pending_comments': pending_comments
            }
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

