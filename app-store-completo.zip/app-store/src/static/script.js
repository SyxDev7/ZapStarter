// Global variables
let allApps = [];
let allCategories = [];
let currentFilter = 'all';
let currentCategory = '';
let isAdminLoggedIn = false;

// API Base URL
const API_BASE = '/api';

// DOM Elements
const elements = {
    totalApps: document.getElementById('total-apps'),
    totalDownloads: document.getElementById('total-downloads'),
    totalCategories: document.getElementById('total-categories'),
    featuredApps: document.getElementById('featured-apps'),
    categoriesList: document.getElementById('categories-list'),
    appsList: document.getElementById('apps-list'),
    loading: document.getElementById('loading'),
    searchInput: document.querySelector('.search-input'),
    categoryFilter: document.getElementById('category-filter'),
    filterBtns: document.querySelectorAll('.filter-btn'),
    appModal: document.getElementById('app-modal'),
    modalBody: document.getElementById('modal-body'),
    adminModal: document.getElementById('admin-modal'),
    adminLogin: document.getElementById('admin-login'),
    adminPanel: document.getElementById('admin-panel'),
    adminLoginForm: document.getElementById('admin-login-form')
};

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    bindEvents();
});

// Initialize application
async function initializeApp() {
    showLoading();
    try {
        await Promise.all([
            loadApps(),
            loadCategories()
        ]);
        updateStats();
        renderFeaturedApps();
        renderCategories();
        renderAllApps();
    } catch (error) {
        console.error('Error initializing app:', error);
        showError('Erro ao carregar dados. Tente novamente.');
    } finally {
        hideLoading();
    }
}

// Bind event listeners
function bindEvents() {
    // Search
    elements.searchInput.addEventListener('input', debounce(handleSearch, 300));
    
    // Filters
    elements.categoryFilter.addEventListener('change', handleCategoryFilter);
    elements.filterBtns.forEach(btn => {
        btn.addEventListener('click', handleFilterClick);
    });
    
    // Navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', handleNavClick);
    });
    
    // Admin
    elements.adminLoginForm.addEventListener('submit', handleAdminLogin);
    
    // Modal close on escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeModal();
            closeAdminModal();
        }
    });
}

// API Functions
async function apiRequest(endpoint, options = {}) {
    try {
        const response = await fetch(`${API_BASE}${endpoint}`, {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('API request failed:', error);
        throw error;
    }
}

async function loadApps() {
    const data = await apiRequest('/apps');
    if (data.success) {
        allApps = data.apps;
    }
}

async function loadCategories() {
    const data = await apiRequest('/categories');
    if (data.success) {
        allCategories = data.categories;
    }
}

async function downloadApp(appId) {
    try {
        const data = await apiRequest(`/apps/${appId}/download`, {
            method: 'POST'
        });
        
        if (data.success) {
            // Open download URL
            window.open(data.download_url, '_blank');
            
            // Update download count in UI
            updateDownloadCount(appId, data.downloads_count);
            updateStats();
        }
    } catch (error) {
        console.error('Download failed:', error);
        showError('Erro ao iniciar download. Tente novamente.');
    }
}

async function addComment(appId, commentData) {
    try {
        const data = await apiRequest(`/apps/${appId}/comments`, {
            method: 'POST',
            body: JSON.stringify(commentData)
        });
        
        if (data.success) {
            return data.comment;
        }
    } catch (error) {
        console.error('Failed to add comment:', error);
        throw error;
    }
}

// Render Functions
function renderFeaturedApps() {
    const featuredApps = allApps.filter(app => app.featured);
    const html = featuredApps.map(app => createFeaturedAppCard(app)).join('');
    elements.featuredApps.innerHTML = html;
}

function renderCategories() {
    // Count apps per category
    const categoryCounts = {};
    allApps.forEach(app => {
        categoryCounts[app.category] = (categoryCounts[app.category] || 0) + 1;
    });
    
    const html = allCategories.map(category => 
        createCategoryCard(category, categoryCounts[category] || 0)
    ).join('');
    elements.categoriesList.innerHTML = html;
    
    // Update category filter dropdown
    const filterOptions = allCategories.map(category => 
        `<option value="${category}">${category}</option>`
    ).join('');
    elements.categoryFilter.innerHTML = '<option value="">Todas as categorias</option>' + filterOptions;
}

function renderAllApps() {
    let filteredApps = [...allApps];
    
    // Apply search filter
    const searchTerm = elements.searchInput.value.toLowerCase();
    if (searchTerm) {
        filteredApps = filteredApps.filter(app => 
            app.name.toLowerCase().includes(searchTerm) ||
            app.description.toLowerCase().includes(searchTerm)
        );
    }
    
    // Apply category filter
    if (currentCategory) {
        filteredApps = filteredApps.filter(app => app.category === currentCategory);
    }
    
    // Apply featured filter
    if (currentFilter === 'featured') {
        filteredApps = filteredApps.filter(app => app.featured);
    }
    
    const html = filteredApps.map(app => createAppCard(app)).join('');
    elements.appsList.innerHTML = html || '<p style="text-align: center; color: var(--text-secondary); padding: 40px;">Nenhum aplicativo encontrado.</p>';
}

// Card Creation Functions
function createFeaturedAppCard(app) {
    const screenshots = app.screenshots ? JSON.parse(app.screenshots) : [];
    
    return `
        <div class="featured-card" onclick="openAppModal(${app.id})">
            <div class="featured-card-header">
                <img src="${app.icon_url || 'https://via.placeholder.com/80x80/4285f4/ffffff?text=APP'}" alt="${app.name}" class="app-icon">
                <div class="app-info">
                    <h3>${app.name}</h3>
                    <div class="app-version">Versão ${app.version}</div>
                    <span class="app-category">${app.category}</span>
                </div>
            </div>
            <p class="app-description">${truncateText(app.description, 120)}</p>
            <div class="app-actions">
                <button class="btn btn-primary" onclick="event.stopPropagation(); downloadApp(${app.id})">
                    <i class="fas fa-download"></i>
                    Download
                </button>
                <span class="download-count">${app.downloads_count} downloads</span>
            </div>
        </div>
    `;
}

function createCategoryCard(category, count) {
    const icons = {
        'Fotografia': 'fas fa-camera',
        'Produtividade': 'fas fa-tasks',
        'Música': 'fas fa-music',
        'Desenvolvimento': 'fas fa-code',
        'Saúde': 'fas fa-heartbeat',
        'Jogos': 'fas fa-gamepad',
        'Educação': 'fas fa-graduation-cap',
        'Negócios': 'fas fa-briefcase',
        'Utilidades': 'fas fa-tools',
        'Entretenimento': 'fas fa-film'
    };
    
    return `
        <div class="category-card" onclick="filterByCategory('${category}')">
            <div class="category-icon">
                <i class="${icons[category] || 'fas fa-folder'}"></i>
            </div>
            <div class="category-name">${category}</div>
            <div class="category-count">${count} app${count !== 1 ? 's' : ''}</div>
        </div>
    `;
}

function createAppCard(app) {
    return `
        <div class="app-card" onclick="openAppModal(${app.id})">
            <div class="app-card-header">
                <img src="${app.icon_url || 'https://via.placeholder.com/60x60/4285f4/ffffff?text=APP'}" alt="${app.name}" class="app-icon">
                <div class="app-info">
                    <h3>${app.name}</h3>
                    <div class="app-version">v${app.version}</div>
                    <span class="app-category">${app.category}</span>
                </div>
            </div>
            <p class="app-description">${truncateText(app.description, 80)}</p>
            <div class="app-actions">
                <button class="btn btn-primary" onclick="event.stopPropagation(); downloadApp(${app.id})">
                    <i class="fas fa-download"></i>
                    Baixar
                </button>
                <span class="download-count">${app.downloads_count} downloads</span>
            </div>
        </div>
    `;
}

// Modal Functions
async function openAppModal(appId) {
    try {
        const data = await apiRequest(`/apps/${appId}`);
        if (data.success) {
            renderAppModal(data.app);
            elements.appModal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    } catch (error) {
        console.error('Error loading app details:', error);
        showError('Erro ao carregar detalhes do aplicativo.');
    }
}

function renderAppModal(app) {
    const screenshots = app.screenshots ? JSON.parse(app.screenshots) : [];
    const comments = app.comments || [];
    
    const screenshotsHtml = screenshots.length > 0 ? `
        <div class="app-screenshots">
            <h3>Capturas de Tela</h3>
            <div class="screenshots-grid">
                ${screenshots.map(screenshot => 
                    `<img src="${screenshot}" alt="Screenshot" class="screenshot">`
                ).join('')}
            </div>
        </div>
    ` : '';
    
    const commentsHtml = `
        <div class="app-comments">
            <div class="comments-header">
                <h3>Comentários (${comments.length})</h3>
            </div>
            
            <form class="comment-form" onsubmit="handleCommentSubmit(event, ${app.id})">
                <div class="form-group">
                    <label>Nome:</label>
                    <input type="text" name="author_name" required>
                </div>
                <div class="form-group">
                    <label>Email (opcional):</label>
                    <input type="email" name="author_email">
                </div>
                <div class="form-group">
                    <label>Avaliação:</label>
                    <div class="rating-input" data-rating="0">
                        ${[1,2,3,4,5].map(i => `<span class="star" data-value="${i}">★</span>`).join('')}
                    </div>
                </div>
                <div class="form-group">
                    <label>Comentário:</label>
                    <textarea name="content" required placeholder="Compartilhe sua experiência com este aplicativo..."></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Enviar Comentário</button>
            </form>
            
            <div class="comments-list">
                ${comments.map(comment => createCommentCard(comment)).join('')}
            </div>
        </div>
    `;
    
    elements.modalBody.innerHTML = `
        <div class="app-detail-header">
            <img src="${app.icon_url || 'https://via.placeholder.com/120x120/4285f4/ffffff?text=APP'}" alt="${app.name}" class="app-detail-icon">
            <div class="app-detail-info">
                <h2>${app.name}</h2>
                <div class="app-detail-meta">
                    <div class="app-version">Versão ${app.version}</div>
                    <span class="app-category">${app.category}</span>
                    <div class="download-count">${app.downloads_count} downloads</div>
                </div>
                <button class="btn btn-primary" onclick="downloadApp(${app.id})">
                    <i class="fas fa-download"></i>
                    Download
                </button>
            </div>
        </div>
        
        <div class="app-detail-description">
            ${app.description}
        </div>
        
        ${screenshotsHtml}
        ${commentsHtml}
    `;
    
    // Initialize rating stars
    initializeRatingStars();
}

function createCommentCard(comment) {
    const rating = comment.rating ? 
        `<div class="comment-rating">
            ${[1,2,3,4,5].map(i => 
                `<span class="star ${i <= comment.rating ? 'active' : ''}">★</span>`
            ).join('')}
        </div>` : '';
    
    const date = new Date(comment.created_at).toLocaleDateString('pt-BR');
    
    return `
        <div class="comment">
            <div class="comment-header">
                <span class="comment-author">${comment.author_name}</span>
                <span class="comment-date">${date}</span>
            </div>
            ${rating}
            <div class="comment-content">${comment.content}</div>
        </div>
    `;
}

function closeModal() {
    elements.appModal.classList.remove('active');
    document.body.style.overflow = '';
}

// Admin Functions
function openAdminModal() {
    elements.adminModal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeAdminModal() {
    elements.adminModal.classList.remove('active');
    document.body.style.overflow = '';
}

async function handleAdminLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('admin-username').value;
    const password = document.getElementById('admin-password').value;
    
    try {
        const data = await apiRequest('/admin/login', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });
        
        if (data.success) {
            isAdminLoggedIn = true;
            elements.adminLogin.style.display = 'none';
            elements.adminPanel.style.display = 'block';
            loadAdminPanel();
        } else {
            showError('Credenciais inválidas');
        }
    } catch (error) {
        console.error('Login failed:', error);
        showError('Erro ao fazer login. Tente novamente.');
    }
}

async function loadAdminPanel() {
    try {
        const data = await apiRequest('/admin/stats');
        if (data.success) {
            renderAdminPanel(data.stats);
        }
    } catch (error) {
        console.error('Failed to load admin stats:', error);
    }
}

function renderAdminPanel(stats) {
    elements.adminPanel.innerHTML = `
        <h3>Painel Administrativo</h3>
        
        <div class="admin-stats">
            <div class="admin-stat-card">
                <div class="admin-stat-number">${stats.total_apps}</div>
                <div class="admin-stat-label">Total de Apps</div>
            </div>
            <div class="admin-stat-card">
                <div class="admin-stat-number">${stats.total_downloads}</div>
                <div class="admin-stat-label">Total de Downloads</div>
            </div>
            <div class="admin-stat-card">
                <div class="admin-stat-number">${stats.total_comments}</div>
                <div class="admin-stat-label">Total de Comentários</div>
            </div>
            <div class="admin-stat-card">
                <div class="admin-stat-number">${stats.pending_comments}</div>
                <div class="admin-stat-label">Comentários Pendentes</div>
            </div>
        </div>
        
        <div style="text-align: center; margin-top: 30px;">
            <p>Funcionalidades administrativas completas estarão disponíveis em breve.</p>
            <button class="btn btn-secondary" onclick="adminLogout()">Sair</button>
        </div>
    `;
}

async function adminLogout() {
    try {
        await apiRequest('/admin/logout', { method: 'POST' });
    } catch (error) {
        console.error('Logout failed:', error);
    } finally {
        isAdminLoggedIn = false;
        elements.adminLogin.style.display = 'block';
        elements.adminPanel.style.display = 'none';
        document.getElementById('admin-username').value = '';
        document.getElementById('admin-password').value = '';
        closeAdminModal();
    }
}

// Event Handlers
function handleSearch() {
    renderAllApps();
}

function handleCategoryFilter(e) {
    currentCategory = e.target.value;
    renderAllApps();
}

function handleFilterClick(e) {
    elements.filterBtns.forEach(btn => btn.classList.remove('active'));
    e.target.classList.add('active');
    currentFilter = e.target.dataset.filter;
    renderAllApps();
}

function handleNavClick(e) {
    e.preventDefault();
    
    const target = e.target.getAttribute('href');
    
    if (target === '#admin') {
        openAdminModal();
        return;
    }
    
    // Update active nav link
    document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
    e.target.classList.add('active');
    
    // Smooth scroll to section
    if (target && target.startsWith('#')) {
        const section = document.querySelector(target);
        if (section) {
            section.scrollIntoView({ behavior: 'smooth' });
        }
    }
}

async function handleCommentSubmit(e, appId) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const rating = parseInt(e.target.querySelector('.rating-input').dataset.rating) || null;
    
    const commentData = {
        author_name: formData.get('author_name'),
        author_email: formData.get('author_email'),
        content: formData.get('content'),
        rating: rating > 0 ? rating : null
    };
    
    try {
        const comment = await addComment(appId, commentData);
        
        // Reset form
        e.target.reset();
        e.target.querySelector('.rating-input').dataset.rating = '0';
        e.target.querySelectorAll('.star').forEach(star => star.classList.remove('active'));
        
        // Refresh app modal
        openAppModal(appId);
        
        showSuccess('Comentário adicionado com sucesso!');
    } catch (error) {
        console.error('Failed to add comment:', error);
        showError('Erro ao adicionar comentário. Tente novamente.');
    }
}

// Utility Functions
function filterByCategory(category) {
    currentCategory = category;
    elements.categoryFilter.value = category;
    renderAllApps();
    
    // Scroll to all apps section
    document.querySelector('.all-apps').scrollIntoView({ behavior: 'smooth' });
}

function updateStats() {
    const totalDownloads = allApps.reduce((sum, app) => sum + app.downloads_count, 0);
    
    animateNumber(elements.totalApps, allApps.length);
    animateNumber(elements.totalDownloads, totalDownloads);
    animateNumber(elements.totalCategories, allCategories.length);
}

function updateDownloadCount(appId, newCount) {
    // Update in allApps array
    const app = allApps.find(a => a.id === appId);
    if (app) {
        app.downloads_count = newCount;
    }
    
    // Update in UI
    const downloadElements = document.querySelectorAll(`[onclick*="downloadApp(${appId})"]`);
    downloadElements.forEach(el => {
        const countEl = el.parentElement.querySelector('.download-count');
        if (countEl) {
            countEl.textContent = `${newCount} downloads`;
        }
    });
}

function animateNumber(element, target) {
    const start = parseInt(element.textContent) || 0;
    const duration = 1000;
    const startTime = Date.now();
    
    function update() {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const current = Math.floor(start + (target - start) * progress);
        
        element.textContent = current.toLocaleString();
        
        if (progress < 1) {
            requestAnimationFrame(update);
        }
    }
    
    update();
}

function initializeRatingStars() {
    const ratingContainer = document.querySelector('.rating-input');
    if (!ratingContainer) return;
    
    const stars = ratingContainer.querySelectorAll('.star');
    
    stars.forEach((star, index) => {
        star.addEventListener('click', () => {
            const rating = index + 1;
            ratingContainer.dataset.rating = rating;
            
            stars.forEach((s, i) => {
                s.classList.toggle('active', i < rating);
            });
        });
        
        star.addEventListener('mouseenter', () => {
            stars.forEach((s, i) => {
                s.style.color = i <= index ? 'var(--warning-color)' : 'var(--border-color)';
            });
        });
        
        star.addEventListener('mouseleave', () => {
            const currentRating = parseInt(ratingContainer.dataset.rating) || 0;
            stars.forEach((s, i) => {
                s.style.color = i < currentRating ? 'var(--warning-color)' : 'var(--border-color)';
            });
        });
    });
}

function truncateText(text, maxLength) {
    if (text.length <= maxLength) return text;
    return text.substr(0, maxLength) + '...';
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function showLoading() {
    elements.loading.style.display = 'flex';
}

function hideLoading() {
    elements.loading.style.display = 'none';
}

function showError(message) {
    // Simple error display - could be enhanced with a toast system
    alert('Erro: ' + message);
}

function showSuccess(message) {
    // Simple success display - could be enhanced with a toast system
    alert('Sucesso: ' + message);
}

