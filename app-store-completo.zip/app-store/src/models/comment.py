from src.models.user import db
from datetime import datetime

class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    app_id = db.Column(db.Integer, db.ForeignKey('app.id'), nullable=False)
    author_name = db.Column(db.String(100), nullable=False)
    author_email = db.Column(db.String(120), nullable=True)
    content = db.Column(db.Text, nullable=False)
    rating = db.Column(db.Integer, nullable=True)  # Rating de 1 a 5 estrelas
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    approved = db.Column(db.Boolean, default=True)  # Para moderação

    def __repr__(self):
        return f'<Comment {self.id} for App {self.app_id}>'

    def to_dict(self):
        return {
            'id': self.id,
            'app_id': self.app_id,
            'author_name': self.author_name,
            'author_email': self.author_email,
            'content': self.content,
            'rating': self.rating,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'approved': self.approved
        }

