# 🔑 Credenciais e Informações Importantes

## Credenciais do Administrador
- **Usuário**: `admin`
- **Senha**: `admin123`
- **Email**: `admin@appstore.com`

⚠️ **IMPORTANTE**: Altere essas credenciais após o primeiro login em produção!

## URLs Importantes
- **Site Principal**: http://localhost:5000
- **Painel Admin**: Clique em "Admin" no menu superior
- **API Base**: http://localhost:5000/api

## Banco de Dados
- **Tipo**: SQLite
- **Localização**: `src/database/app.db`
- **Backup**: Copie o arquivo `app.db` para fazer backup

## Estrutura de Pastas Importantes
```
app-store/
├── src/static/          # Arquivos do frontend (HTML, CSS, JS)
├── src/models/          # Modelos do banco de dados
├── src/routes/          # APIs e rotas
├── src/database/        # Banco de dados SQLite
└── venv/               # Ambiente virtual Python
```

## Como Adicionar Novos Aplicativos

### Via API (Recomendado)
```bash
curl -X POST http://localhost:5000/api/admin/apps \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Nome do App",
    "description": "Descrição detalhada do aplicativo",
    "version": "1.0.0",
    "category": "Categoria",
    "download_url": "https://link-para-download.com",
    "icon_url": "https://link-para-icone.com",
    "screenshots": ["https://screenshot1.com", "https://screenshot2.com"],
    "featured": true
  }'
```

### Via Banco de Dados Direto
```python
from src.main import app
from src.models.user import db
from src.models.app import App
import json

with app.app_context():
    novo_app = App(
        name='Nome do App',
        description='Descrição detalhada',
        version='1.0.0',
        category='Categoria',
        download_url='https://link-download.com',
        icon_url='https://link-icone.com',
        screenshots=json.dumps(['https://screenshot1.com']),
        featured=True
    )
    db.session.add(novo_app)
    db.session.commit()
```

## Categorias Disponíveis
- Fotografia
- Produtividade  
- Música
- Desenvolvimento
- Saúde
- Jogos
- Educação
- Negócios
- Utilidades
- Entretenimento

## Comandos Úteis

### Iniciar o Servidor
```bash
cd app-store
source venv/bin/activate
python src/main.py
```

### Backup do Banco
```bash
cp src/database/app.db backup_$(date +%Y%m%d).db
```

### Ver Logs
```bash
tail -f server.log
```

### Atualizar Dependências
```bash
source venv/bin/activate
pip freeze > requirements.txt
```

## Personalização Rápida

### Alterar Cores
Edite `src/static/styles.css` nas variáveis CSS:
```css
:root {
    --primary-color: #007AFF;    /* Azul principal */
    --accent-color: #FF3B30;     /* Vermelho de destaque */
    --background-color: #F2F2F7; /* Cinza de fundo */
}
```

### Alterar Título do Site
Edite `src/static/index.html`:
```html
<title>Seu Nome - Loja de Aplicativos</title>
```

### Alterar Logo
Edite `src/static/index.html` na seção do logo:
```html
<div class="logo">
    <i class="fas fa-mobile-alt"></i>
    <span>Seu Nome</span>
</div>
```

## Solução de Problemas

### Erro de Porta em Uso
```bash
# Encontrar processo usando a porta 5000
lsof -i :5000
# Matar o processo
kill -9 [PID]
```

### Erro de Permissão
```bash
chmod +x src/main.py
```

### Banco de Dados Corrompido
```bash
# Deletar banco atual
rm src/database/app.db
# Recriar banco
python -c "from src.main import app, db; app.app_context().push(); db.create_all()"
```

## Contato e Suporte
- Verifique o arquivo `README.md` para documentação completa
- Logs do servidor ficam em `server.log`
- Para problemas, verifique as mensagens de erro no terminal

---
**Criado em**: $(date)
**Versão**: 1.0.0

