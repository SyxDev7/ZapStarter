from src.models.user import db
from datetime import datetime

class App(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    version = db.Column(db.String(20), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    icon_url = db.Column(db.String(255), nullable=True)
    download_url = db.Column(db.String(255), nullable=False)
    screenshots = db.Column(db.Text, nullable=True)  # JSON string com URLs das capturas
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    downloads_count = db.Column(db.Integer, default=0)
    featured = db.Column(db.Boolean, default=False)
    
    # Relacionamento com comentários
    comments = db.relationship('Comment', backref='app', lazy=True, cascade='all, delete-orphan')

    def __repr__(self):
        return f'<App {self.name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'version': self.version,
            'category': self.category,
            'icon_url': self.icon_url,
            'download_url': self.download_url,
            'screenshots': self.screenshots,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'downloads_count': self.downloads_count,
            'featured': self.featured
        }

